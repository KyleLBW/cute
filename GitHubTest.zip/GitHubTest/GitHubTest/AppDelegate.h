//
//  AppDelegate.h
//  GitHubTest
//
//  Created by Kyle on 2017/8/1.
//  Copyright © 2017年 lyj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

